# Panel del Cliente y canal de campo · Agroblindaje Inteligente™ · SSCAE

Arquitectura **v2**: Netlify + funciones serverless + Airtable, con webhooks
nativos de Mifiel y Stripe. **Sin plataforma de automatización intermediaria.**

La frontera de aislamiento entre clientes es el campo de fórmula **Cliente Id**
de la tabla Operaciones (lookup encadenado Clientes → Contratos → Operaciones):
todo endpoint lo deriva de la **sesión firmada** o del **número telefónico**
registrado, jamás de un parámetro del navegador.

---

## 1. Estructura del repositorio

```
netlify.toml            configuración (Node 24, redirects, cabeceras, cron, env docs)
.node-version           fija Node 24 también para desarrollo local
package.json            metadatos; sin dependencias de producción
.gitignore              excluye node_modules, .env y artefactos locales
.env.example            plantilla de variables (NUNCA subir el .env real)

public/                 frontend estático, ~35 KB, sin dependencias
  index.html + acceso.js    P-0 · acceso por código de un solo uso
  panel.html  + app.js      P-1 resumen · P-2 listado · P-3 detalle · P-4 vencimientos
  estilos.css               móvil primero, alto contraste, semáforo con etiqueta
  contraparte.html + .js    pantalla única del deudor, servida en /c/<token>

netlify/functions/
  ── módulos compartidos (el prefijo _ evita que Netlify los publique
     como endpoints; sólo se importan) ──
  _lib.js               sesión HMAC, Airtable, filtros, semáforo, bitácora
  _whatsapp.js          Cloud API: texto, botones, listas, plantillas, medios, firma
  _mifiel.js            API de Mifiel: autenticación APIAuth, crear desde plantilla
  _documentos.js        campos de fusión + disparo de Ficha, Pagaré y Constancia
  _letras.js            importes a letra (gramática cambiaria)
  _liga.js              emisión y resolución de la liga de contraparte
  _stripe.js            sesiones de Checkout para el botón de pago

  ── endpoints del Panel ──
  acceso-solicitar.js   genera código y lo envía por Cloud API directo
  acceso-validar.js     valida, bloquea por intentos, emite cookie 24 h
  resumen.js            indicadores P-1 (caché 60 s)
  operaciones.js        tarjetas P-2/P-4 con búsqueda y filtro
  operacion.js          detalle P-3 (pertenencia verificada; ajeno = 404)
  salir.js              cierre de sesión

  ── canal de campo y webhooks ──
  whatsapp-entrante.js  motor conversacional (máquina de estados §6 del Árbol)
  mifiel-callback.js    webhook nativo de firma (3 capas de validación)
  stripe-webhook.js     webhook de cobro (firma v1 verificada)
  alertas-diarias.js    cron 07:00 QRO · plantillas D-7 y D-0
  numero-a-letras.js    utilería autenticada (opcional)

  ── liga de la contraparte y formularios ──
  contraparte-ver.js    datos de la pantalla del deudor (público, token firmado)
  contraparte-pagar.js  crea el pago en línea por el saldo vigente
  formulario-recibido.js  valida el formulario y retoma la conversación

airtable/
  automatizacion-formulario-recibido.js   script para la automatización nativa
```

> **Si ya tenías la versión anterior**, esta carpeta la reemplaza por completo.
> Las funciones del zip `Funciones_v2_SSCAE` (`mifiel-callback.js` y
> `stripe-webhook.js`) **ya están integradas aquí** y adaptadas: usan `_lib.js`
> y `_mifiel.js` en vez de duplicar código. No hay que copiarlas por separado.
> Lo que sí desaparece: las variables `ZAPIER_OTP_WEBHOOK_URL` y
> `ZAPIER_WEBHOOK_SECRET`, que deben borrarse de Netlify.

---

## 2. Despliegue desde GitHub

### 2.1 Subir el repositorio

**La causa más común de un 404 tras el primer despliegue** es que el contenido
quede dentro de una subcarpeta del repositorio. Hay dos caminos válidos:

**Opción A — contenido en la raíz (recomendada).** El repositorio se ve así:

```
mi-repo/
  netlify.toml
  public/
  netlify/
  package.json
```

En Netlify, "Base directory" se deja **vacío**.

**Opción B — contenido en subcarpeta.** Si el repositorio queda así:

```
mi-repo/
  panel-cliente/
    netlify.toml
    public/
    netlify/
```

entonces en Netlify hay que definir **Base directory = `panel-cliente`**.
Sin eso, Netlify no encuentra `netlify.toml`, ignora `publish = "public"` y
sirve un 404.

```bash
cd panel-cliente
git init
git add .
git commit -m "Panel del Cliente SSCAE v2"
git branch -M main
git remote add origin https://github.com/<usuario>/<repo>.git
git push -u origin main
```

### 2.2 Crear el sitio en Netlify

1. **Add new site → Import an existing project → GitHub**, autoriza y elige el repo.
2. Build command: **vacío**. Publish directory: **`public`** (o déjalo que lo tome
   de `netlify.toml`). Base directory según 2.1.
3. **Deploy site.** El primer despliegue fallará funcionalmente hasta cargar las
   variables: es lo esperado.

### 2.3 Versión de Node

El proyecto corre en **Node 24** (Active LTS hasta abril de 2028). Esto no es
opcional: Node 20 llegó a su fin de vida el 30 de abril de 2026, y AWS Lambda
—sobre el que corren las funciones de Netlify— bloquea la creación de funciones
`nodejs20.x` desde el 31 de agosto de 2026 y sus actualizaciones desde el 30 de
septiembre. Desplegar en Node 20 hoy significa quedarse sin parches de seguridad
y sin poder actualizar las funciones.

La versión se fija en tres lugares, ya configurados:

| Dónde | Valor | Para qué |
|---|---|---|
| `netlify.toml` → `NODE_VERSION` | `24` | versión del build |
| `.node-version` | `24` | desarrollo local y respaldo del build |
| `package.json` → `engines` | `>=22` | mínimo tolerado al desarrollar |

El runtime de las funciones hereda la versión del build, así que normalmente no
hay que hacer nada más. Si quieres fijarlo de forma explícita, define
`AWS_LAMBDA_JS_RUNTIME = nodejs24.x` **en la UI de Netlify** (Environment
variables) — esa variable no se lee desde `netlify.toml`.

> **Compatibilidad verificada.** El proyecto no tiene dependencias npm ni usa
> APIs removidas en Node 21–24 (`url.parse`, `new Buffer()`, `punycode`,
> `crypto.createCipher`). Solo importa `node:crypto`. Los algoritmos que exige
> la API de Mifiel (MD5 para `Content-MD5`, HMAC-SHA1 para `APIAuth`) siguen
> disponibles en el proveedor por defecto de OpenSSL 3, que es el que trae
> Node 24; solo se bloquearían en modo FIPS, que Netlify no activa.

### 2.4 Cargar las variables de entorno

**Site configuration → Environment variables → Add a variable.** La lista
completa y comentada está al final de `netlify.toml`; `.env.example` sirve de
plantilla. Genera cada secreto por separado, nunca reutilices el mismo:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

Úsalo para `SESION_SECRET`, `MIFIEL_CALLBACK_TOKEN`, `WHATSAPP_VERIFY_TOKEN`
y `UTILIDADES_SECRET` (uno distinto para cada uno).

Tras cargarlas: **Deploys → Trigger deploy → Clear cache and deploy site.**

### 2.5 Token de Airtable

Airtable acota los PAT **por base o por workspace, nunca por tabla**: la
restricción por tabla no existe en la plataforma y se sostiene en el código,
que sólo nombra las tablas que necesita.

En `airtable.com/create/tokens`:
- Scopes: `data.records:read` **y** `data.records:write`
  (el Panel escribe: hash del código, intentos, bitácora, estatus de firma y cobro).
- Access: **Add a base → app9YewbU1P5QoQdM** (no el workspace completo).

---

## 3. Conectar WhatsApp Cloud API

1. En **Meta for Developers → tu app → WhatsApp → Configuration → Webhook**:
   - Callback URL: `https://<tu-sitio>.netlify.app/api/whatsapp-entrante`
   - Verify token: el valor exacto de `WHATSAPP_VERIFY_TOKEN`
   - **Verify and save** → Meta llama con GET y la función responde el `challenge`.
2. **Webhook fields → suscribir `messages`.** Sin esa suscripción no llega nada.
3. Copia el **App Secret** (Settings → Basic) a `WHATSAPP_APP_SECRET`: valida la
   firma `X-Hub-Signature-256` de cada webhook. Sin ella, cualquiera podría
   inyectar mensajes falsos al motor conversacional.
4. Aprueba las plantillas en Meta:

| Plantilla | Categoría | Variables |
|---|---|---|
| `sscae_codigo_acceso` | Autenticación | `{{1}}` código |
| `sscae_alerta_d7` | Utilidad | 4 variables + botón con URL dinámica — ver §7.1 |
| `sscae_alerta_d0` | Utilidad | 4 variables + botón con URL dinámica — ver §7.1 |
| `sscae_alerta_d7_sin_liga`, `sscae_alerta_d0_sin_liga` | Utilidad | 4 variables, sin botón |

5. **Fecha límite:** registra el método de pago en la cuenta de WhatsApp
   Business antes del **30 de septiembre de 2026**, o Meta deja de entregar los
   mensajes de servicio y se interrumpe el canal de campo.

---

## 4. Conectar Mifiel

1. Contrata la funcionalidad **Plantillas de documentos** (es un plan aparte que
   se solicita por chat en mifiel.com; no es autoservicio).
2. Sube los tres HTML (`Plantilla_Mifiel_*.html`) y anota el id de cada plantilla
   en `MIFIEL_PLANTILLA_FICHA`, `_PAGARE` y `_CONSTANCIA`.
3. Credenciales de API → `MIFIEL_APP_ID` y `MIFIEL_APP_SECRET`.
4. **Las URLs de callback NO se configuran en el panel de Mifiel.** Se declaran
   al crear cada documento, y `_documentos.js` ya lo hace:
   `https://<tu-sitio>.netlify.app/api/mifiel-callback?t=<MIFIEL_CALLBACK_TOKEN>`
5. Para pruebas, apunta `MIFIEL_API_URL` al sandbox antes de operar en real.

---

## 5. Conectar Stripe

1. **Dashboard → Developers → Webhooks → Add endpoint:**
   `https://<tu-sitio>.netlify.app/api/stripe-webhook`
2. Eventos: `payment_intent.succeeded`, `payment_intent.payment_failed`,
   `charge.succeeded`, `charge.failed`, `charge.dispute.created`,
   `invoice.payment_succeeded`, `invoice.payment_failed`.
3. Copia el secreto de firma (`whsec_…`) a `STRIPE_WEBHOOK_SECRET`.
4. **Requisito de correlación:** al crear cada PaymentIntent o suscripción hay
   que escribir `metadata.folio_operacion` con el folio (`OP-0144`). Sin ese
   metadato la función registra el evento pero no puede localizar la operación.

---

## 6. Qué hace el canal de campo

`whatsapp-entrante.js` implementa la máquina de estados del §6 del Árbol. El
estado vive en la tabla **Sesiones de campo** porque la función no conserva
memoria entre invocaciones: leer sesión → validar contra el paso → responder →
escribir sesión.

| Rama | Pasos | Al confirmar |
|---|---|---|
| **ALTA** | contraparte → descripción → cantidad → monto → anticipo → plazo → aval → resumen | Crea la operación y, **en la misma ejecución**, genera Ficha y Pagaré en Mifiel |
| **ENTREGA** | operación → evidencia → alcance → quién recibe → estado → resumen | Fija la fecha real de recepción (el vencimiento se recalcula), sube las fotos y genera la Constancia |
| **PAGO** | operación → alcance → monto → medio → comprobante → resumen | Crea un **Pago reportado** con estatus «Por conciliar» |

**Regla de conciliación (§5 del Árbol):** lo reportado por WhatsApp **no
liquida**. El único evento que marca «Liquidada» automáticamente es el webhook
de Stripe con un cobro que cubre el saldo. Esto protege la cartera de
liquidaciones de buena fe que nunca se reflejaron en el banco.

Comandos globales: `CANCELAR`, `MENÚ`, `AYUDA`, `ESTATUS OP-0144`.
Atajos de rama: `ALTA`, `ENTREGA`, `PAGO`.

**Permisos por rol** (títulos de las secciones 3 a 5 del Árbol):

| Rama | Roles |
|---|---|
| Alta de operación | Dirección, Ventas |
| Registro de entrega | todos los roles activos (incluido personal de campo) |
| Reporte de pago | Dirección, Cobranza |

El menú solo muestra las opciones permitidas. Se ajustan en `PERMISOS`, al
inicio de `whatsapp-entrante.js`.

**Conducta conforme a las convenciones del Árbol (§2):**
- `CORREGIR`, en cualquier resumen, muestra la lista de datos capturados; se
  reemplaza uno y se vuelve al resumen, sin repetir el flujo.
- `MENÚ` con una captura en curso pregunta antes de descartarla.
- Una respuesta que no corresponde al paso repite la pregunta una vez; a la
  segunda, ofrece seguir o cancelar.
- Una captura sin confirmar caduca a las 24 horas y se descarta **con aviso**;
  al volver después de 30 minutos, el bot retoma en el mismo paso y recuerda
  que se puede cancelar.
- Una foto enviada sin contexto se conserva (2 horas) y cuenta como evidencia si
  se registra la entrega.
- **Idempotencia:** el id de cada mensaje se anota en `Últimos mensajes` antes de
  procesarlo; si Meta reentrega el webhook, se ignora. La entrega verifica
  además que la Constancia no exista ya, y el alta conserva su antiduplicado de
  10 minutos.

---

## 7. Liga de la contraparte deudora (§15.7 del Pliego)

Una pantalla, sin sesión ni contraseña: **qué debe, cuándo vence, qué firmó y un
botón para pagar**, más un acceso para aclaraciones que canaliza la discusión al
Protocolo de Controversia en lugar de a una llamada.

**Cómo llega al deudor.** Cada recordatorio D-7 y D-0 emite una liga nueva y la
envía como botón de la plantilla. La liga anterior queda sin efecto
automáticamente: cada operación tiene **una sola liga vigente** a la vez.

**Qué puede ver.** Solo operaciones que comparten **el mismo acreedor y la misma
contraparte** que la operación de origen. La contraparte se identifica por su
registro en el catálogo (`Contraparte Id`), **nunca por el RFC**, que es opcional;
las operaciones anteriores al vínculo se reconocen por teléfono a 10 dígitos
**más** nombre (el teléfono solo no basta: en el campo varios productores suelen
usar el número de un familiar). Sin llave suficiente, la liga funciona igual y
muestra solo la operación de origen. Todo se lee del registro, nunca del
navegador. Otra operación del mismo deudor con otro cliente del despacho no
aparece.

**Cuándo deja de servir.** Al emitirse la siguiente, al vaciar el campo
`Liga contraparte · jti` (revocación inmediata) o al cumplirse
`LIGA_VIGENCIA_DIAS`. No muere al abrirse, a propósito: el deudor necesita volver
después de pagar, y una liga de un solo clic generaría justo la llamada que se
quiere evitar.

**El pago.** El botón cobra el saldo vigente según Airtable en ese momento, no un
monto enviado por el navegador. La liquidación la asienta `/api/stripe-webhook`
al confirmarse el pago, con idempotencia (los reintentos de Stripe no duplican
el cobro) y acumulando en `Monto cobrado (MXN)`, de modo que un pago parcial
reduce el saldo por sí mismo. Si la operación está en disputa, el botón no se
muestra.

**Evidencia.** La primera consulta queda asentada en
`Liga contraparte · primera consulta` y en la bitácora: acredita que la
contraparte tuvo a la vista el adeudo. **No sustituye al requerimiento formal de
pago.**

### 7.1 Plantillas de Meta con botón

Las dos alertas se redefinen con un botón de URL dinámica (el sufijo es el token):

| Plantilla | Cuerpo | Botón «Visitar sitio web» |
|---|---|---|
| `sscae_alerta_d7` | `{{1}}` contraparte · `{{2}}` saldo · `{{3}}` vencimiento · `{{4}}` acreedor | «Ver y pagar» → `https://<sitio>/c/{{1}}` |
| `sscae_alerta_d0` | igual | igual |
| `sscae_alerta_d7_sin_liga` y `sscae_alerta_d0_sin_liga` | igual, sin botón | — (solo si `LIGA_SECRET` no está configurado; ya no dependen del RFC) |

Texto sugerido para `sscae_alerta_d7`:
> Hola {{1}}. Te recordamos que tu saldo de {{2}} con {{4}} vence el {{3}}.
> Consulta el detalle, lo que firmaste y paga en línea desde el botón.

### 7.2 Variables

| Variable | Valor recomendado | Reglas |
|---|---|---|
| `LIGA_SECRET` | cadena aleatoria propia | Obligatoria. **Cambiarla anula todas las ligas vigentes.** |
| `LIGA_VIGENCIA_DIAS` | `20` | Entero de 8 a 60. Con menos de 8, la liga del D-7 moriría antes del vencimiento; fuera de rango se usa 20. |
| `STRIPE_METODOS_PAGO` | `card` o `card,oxxo` | Solo `card` y `oxxo`. Para `oxxo`, actívalo antes en Stripe (Settings → Payment methods), o Stripe rechazará el pago. Valores desconocidos se ignoran. |
| `STRIPE_OXXO_DIAS` | `3` | Opcional. Vigencia de la ficha OXXO, de 1 a 7 días. |

OXXO conviene en el agro, donde buena parte de las contrapartes paga en efectivo:
el pago se confirma cuando el deudor paga en tienda, días después, y entonces el
webhook liquida la operación sin intervención.

> Verifica en Netlify que cada variable tenga el **scope «Functions»** (o «All
> scopes»). Una variable limitada a «Builds» no llega a las funciones.

---

## 8. Formularios de comprador nuevo y aval

El domicilio de emplazamiento, la identificación oficial y —si existe— el RFC no
se teclean en el chat. El bot envía una
liga a un formulario de Airtable con un **token firmado oculto**, deja la
conversación **en espera** y la retoma sola en cuanto el formulario se envía.
El vendedor no vuelve a escribir `ALTA` ni pierde lo capturado.

**Flujo.** WhatsApp → liga con token → formulario de Airtable → automatización
nativa de Airtable → `/api/formulario-recibido` → validación (token,
domicilio, identificación, correo; el RFC solo si se capturó) → la conversación continúa en WhatsApp. Si un dato es
inválido, el bot explica qué corregir y reenvía la liga con lo ya capturado
prellenado. Lo validado queda en el catálogo: la siguiente venta a ese comprador,
o con ese aval, ya aparece en la lista y no requiere formulario.

**Aislamiento.** El formulario es público, pero sin un token válido nada entra a
la cartera de ningún cliente: el cliente y el tipo de captura salen del token,
no del formulario, y el registro queda «Rechazada».

**Identidad sin RFC.** El RFC es un dato **opcional** en todo el SSCAE. La llave
primaria de una contraparte es su **registro en `Contrapartes`**, que la operación
guarda en el vínculo `Contraparte` (y el aval en `Aval (registro)`). La
identificación documental descansa en nombre, domicilio de emplazamiento e
**identificación oficial** (obligatoria para comprador y aval). Ningún flujo —alta,
firma, entrega, alertas, liga, cobro— se detiene porque falte el RFC; los
documentos imprimen «—». A Mifiel no se envía `tax_id` salvo que
`MIFIEL_ENVIAR_RFC=1` (y nunca actives la «restricción por RFC» en la cuenta).
Para firmantes sin e.firma, pide al soporte de Mifiel habilitar la **firma con
verificación de identidad** (selfie + INE o pasaporte; consume un crédito por
intento) y confirma por escrito que aplica a documentos creados por API.

### 8.1 Preparar Airtable (una sola vez)

1. **Tabla `Contrapartes`** con estos campos (los crea el asistente por el
   conector una vez que la tabla exista):

| Campo | Tipo | Quién lo escribe |
|---|---|---|
| Nombre o razón social | texto (primario) | formulario |
| Tipo | selección: Comprador · Aval | prellenado oculto; el Panel lo fija desde el token |
| RFC | texto | formulario, **opcional**; si se captura, el Panel lo valida y normaliza |
| Domicilio | texto largo | formulario |
| Representante | texto | formulario |
| Identificación | texto | formulario |
| Teléfono | teléfono | formulario |
| Correo | correo | formulario |
| Token | texto | prellenado oculto |
| Cliente | vínculo → Prospectos / Clientes | el Panel, tras validar el token |
| Cliente Id | lookup de `Record ID` vía Cliente | fórmula (aislamiento) |
| Estatus | selección: Por validar · Validada · Rechazada | el Panel |
| Motivo de rechazo | texto largo | el Panel |
| Record ID | fórmula `RECORD_ID()` | **llave primaria de identidad** de la contraparte |
2. **Dos vistas de formulario** sobre esa tabla:

| Formulario | Campos visibles | Obligatorios |
|---|---|---|
| **Comprador nuevo** | Nombre o razón social, Domicilio, Identificación, Teléfono, Correo, Representante, RFC | Nombre, Domicilio, Identificación, Teléfono, Correo |
| **Aval** | Nombre o razón social, Domicilio, Identificación, Correo, Representante, RFC | Nombre, Domicilio, Identificación, Correo |

   **El RFC nunca es obligatorio** (muchos productores no están inscritos). En la
   descripción del campo dentro del formulario conviene poner: «Opcional. Si no
   estás inscrito en el SAT, déjalo en blanco».

   En **ambos** formularios agrega también los campos `Token` y `Tipo` (el bot
   los prellena y los oculta con `hide_`; no los captura nadie). **No** agregues
   `Cliente`, `Estatus` ni `Motivo de rechazo`: los escribe el Panel.
3. En cada formulario: **Share form → Copy link**. Esas dos ligas van en
   `FORM_CONTRAPARTE_URL` y `FORM_AVAL_URL`.
4. **Dos automatizaciones** (Automations → Create):
   disparador «When a form is submitted» (una por formulario) → acción
   «Run a script» con el contenido de `airtable/automatizacion-formulario-recibido.js`,
   variable de entrada `recordId` = *Airtable record ID* del disparador.
   Sustituye `<SITIO>` y `<SECRETO>` (= `AUTOMATIZACION_SECRET`). **Actívalas.**

### 8.2 Variables

`FORM_CONTRAPARTE_URL`, `FORM_AVAL_URL`, `FORMULARIOS_SECRET` y
`AUTOMATIZACION_SECRET` — los dos secretos distintos entre sí y de todos los demás.

---

## 9. Seguridad implementada

- Cookie HttpOnly + Secure + SameSite=Strict; token HMAC-SHA256; 24 h.
- `Activo` se revalida contra Airtable en **cada** petición.
- Código de un solo uso: sólo se guarda su SHA-256; expira en 10 min; se consume
  al validar; comparación en tiempo constante.
- Bloqueo temporal tras 5 intentos fallidos.
- Respuesta neutra en `acceso-solicitar`: no revela el padrón de usuarios.
- Detalle ajeno responde **404 «no encontrada»**, nunca 403.
- **Mifiel:** tres capas — token en query string, HMAC de cabecera opcional y
  **reconfirmación contra la API** antes de escribir. Si la reconfirmación falla,
  no se escribe nada: se prefiere perder el evento a corromper la cartera.
- **Stripe:** firma v1 sobre el cuerpo crudo, tolerancia de 5 min contra replay,
  soporte de varias firmas durante rotación de secreto.
- **WhatsApp:** firma `X-Hub-Signature-256` verificada antes de interpretar nada.
- **Liga de contraparte:** token HMAC con secreto propio; una liga vigente por
  operación; aislamiento por acreedor + registro de contraparte (nunca por RFC); cualquier irregularidad responde lo
  mismo (404), sin revelar la causa.
- **Formularios:** token firmado oculto con caducidad de 2 h; el registro se
  relee de Airtable y el tipo y el cliente salen del token, nunca del formulario.
- El token de Airtable vive sólo en variables de entorno del servidor.
- CSP estricta, sin scripts de terceros ni fuentes externas.
- Errores hacia el navegador genéricos; el detalle queda en los logs.

---

## 10. Qué NO expone el Panel

FACTORES y CONSTANTES del motor de vectores, precios de paquetes, pipeline
comercial del despacho y cualquier dato de otros clientes. Ningún endpoint
devuelve registros completos: cada función lista explícitamente sus campos.

---

## 11. Verificación tras el despliegue

```bash
# 1. El sitio sirve la pantalla de acceso (no 404)
curl -I https://<tu-sitio>.netlify.app/

# 2. Endpoint protegido responde 401 sin sesión
curl -i https://<tu-sitio>.netlify.app/api/resumen

# 3. Handshake de Meta (debe devolver "prueba")
curl "https://<tu-sitio>.netlify.app/api/whatsapp-entrante?hub.mode=subscribe&hub.verify_token=<TU_VERIFY_TOKEN>&hub.challenge=prueba"

# 4. Webhook sin firma válida debe rechazar (403)
curl -i -X POST https://<tu-sitio>.netlify.app/api/whatsapp-entrante -d '{}'
```

Después: da de alta un usuario en **Usuarios de Panel** (con `Activo` marcado y
su teléfono en formato `+52…`), entra al Panel y escribe `ALTA` por WhatsApp.

---

## 12. Pendiente

- `expediente.js` (P-5: descarga de PDFs firmados desde Mifiel y concatenación)
  — Etapa 5 del Pliego.

- **Campos de Airtable a verificar** antes de operar en real: `Aval · Identificación`,
  `Aval · Correo`, `Sello NOM-151 · Ficha / Pagaré / Constancia`, `Hash · Pagaré`,
  `Fecha real de recepción`, `Persona que recibe`, `Estado / calidad`,
  `Cantidad entregada`, `Observaciones recepción`. Si alguno falta, Airtable
  rechaza la escritura con error 422 (`UNKNOWN_FIELD_NAME`) y quedará en los logs.
