# Panel del Cliente · Agroblindaje Inteligente™ · SSCAE

Interfaz de solo lectura para clientes del SSCAE. Netlify + funciones serverless
+ Airtable, conforme al Pliego Funcional v1.1. La frontera de aislamiento entre
clientes es el campo vinculado **Cliente** de la tabla Operaciones: todo endpoint
deriva el cliente de la **sesión firmada** y lo aplica en la fórmula de filtro de
Airtable; ningún parámetro del navegador participa en esa decisión.

## Estructura
```
netlify.toml                     configuración (NODE 20, redirects, cabeceras, cron)
public/                          frontend estático (~30 KB total, sin dependencias)
  index.html + acceso.js         P-0 · acceso por código de un solo uso
  panel.html + app.js            P-1 resumen · P-2 listado · P-3 detalle · P-4 vencimientos
  estilos.css                    móvil primero, alto contraste, semáforo con etiqueta
netlify/functions/
  _lib.js                        sesión HMAC, Airtable, filtros por cliente y rol, semáforo
  acceso-solicitar.js            genera código, dispara Zap de envío (respuesta neutra)
  acceso-validar.js              valida código, bloqueo por intentos, emite cookie 24 h
  resumen.js                     indicadores P-1 (caché 60 s)
  operaciones.js                 tarjetas P-2/P-4 con búsqueda y filtro
  operacion.js                   detalle P-3 (pertenencia verificada; ajeno = 404)
  salir.js                       cierre de sesión
  numero-a-letras.js             utilería para el Pagaré (la llama Zapier con secreto)
  alertas-diarias.js             cron 07:00 QRO · WhatsApp Cloud API directo (regla §17.6)
```

## Despliegue (20 minutos)
1. Crear un proyecto de Netlify **separado** del sitio comercial (decisión §15.1)
   y conectar esta carpeta (o `netlify deploy --prod` desde ella).
2. Cargar las variables de entorno listadas al final de `netlify.toml`.
3. En Airtable, crear la tabla **Usuarios de Panel** y los campos de Operaciones
   conforme a `Esquema_Campos_SSCAE.xlsx`, incluido el campo de fórmula
   **Cliente Id** (lookup del RECORD_ID() del cliente vinculado) que usan los filtros.
4. Crear el Zap "Envío de código de acceso": webhook → WhatsApp (plantilla
   de autenticación `es_MX`). El webhook recibe {nombre, telefono, correo, codigo}
   y el encabezado X-SSCAE-Secreto.
5. Aprobar en Meta las plantillas de utilidad `sscae_alerta_d7` y `sscae_alerta_d0`.
6. Alta del primer usuario en Usuarios de Panel (Activo ☑) y prueba de acceso.

## Reglas de seguridad implementadas
- Cookie HttpOnly + Secure + SameSite=Strict; token HMAC-SHA256; vigencia 24 h.
- `Activo` se revalida contra Airtable en **cada** petición (§4.3).
- Código de un solo uso: solo se guarda su SHA-256; expira en 10 min; se consume al validar.
- Bloqueo temporal tras 5 intentos fallidos (§4.2).
- Respuesta neutra en acceso-solicitar (no revela el padrón).
- Detalle ajeno responde **404 «no encontrada»**, nunca 403 (§11.2).
- El token de Airtable vive solo en variables de entorno del servidor; el
  navegador jamás habla con Airtable.
- CSP estricta, sin scripts de terceros, sin fuentes externas.
- Los mensajes de error hacia el navegador son genéricos; el detalle queda en logs.

## Qué NO expone este Panel (lista de exclusión §8.1)
FACTORES y CONSTANTES del motor de vectores, precios de paquetes, pipeline
comercial del despacho, y cualquier dato de otros clientes. Ningún endpoint
devuelve registros completos: cada función lista explícitamente sus campos.

## Etapas pendientes (según §14 del Pliego)
- `expediente.js` (P-5: descarga de PDFs firmados vía API de Mifiel y
  concatenación) — Etapa 5.
- Vista de contraparte deudora por liga firmada de un solo uso — v1.1 (§16.7).
